package Models;

public enum TypeMaker {
	CIUTAT, BOSC, OCEA
}
